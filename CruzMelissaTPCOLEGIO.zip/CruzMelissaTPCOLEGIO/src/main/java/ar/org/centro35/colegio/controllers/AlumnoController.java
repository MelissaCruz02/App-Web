package ar.org.centro35.colegio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro35.colegio.entities.Alumnos;
import ar.org.centro35.colegio.repositories.AlumnoRepository;


@Controller
public class AlumnoController {
    
    private AlumnoRepository alumnoRepository=new AlumnoRepository();
    private String mensajeAlumno="Ingrese sus datos!";

    @GetMapping("/alumnos")
    public String getAlumnos(@RequestParam(name="buscar", defaultValue ="")String buscar,Model model) {
        model.addAttribute("mensaje", mensajeAlumno);
        model.addAttribute("alumno", new Alumnos());
        
        return "alumnos";
    }

    @PostMapping("/alumnosSave")
    public String alumnosSave(@ModelAttribute Alumnos alumnos){
        alumnoRepository.save(alumnos);
        if (alumnos.getId()!=0) {
            mensajeAlumno="Se guardo registro de Alumno id: "+alumnos.getId();
        } else {
            mensajeAlumno="No se pudo guardar registro del alumno";
        }
        return"redirect:alumnos";
    }
}
