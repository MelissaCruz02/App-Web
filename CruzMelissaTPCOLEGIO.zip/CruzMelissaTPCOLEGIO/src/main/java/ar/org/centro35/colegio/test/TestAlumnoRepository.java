package ar.org.centro35.colegio.test;

import ar.org.centro35.colegio.entities.Alumnos;
import ar.org.centro35.colegio.repositories.AlumnoRepository;

public class TestAlumnoRepository {
    public static void main(String[] args) {
        AlumnoRepository alumnoRepository=new AlumnoRepository();
        Alumnos alumno=new Alumnos(0, "Juan", "Perez", 22,  13);
        alumnoRepository.save(alumno);
        System.out.println(alumno);
        System.out.println("********************************************************************");
    }
}
